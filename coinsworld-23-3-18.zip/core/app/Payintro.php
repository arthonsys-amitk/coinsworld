<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payintro extends Model
{
    protected $fillable = array('heading', 'details');
}
