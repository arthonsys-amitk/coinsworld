<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sericon extends Model
{
     protected $fillable = array('icon', 'name');
}
