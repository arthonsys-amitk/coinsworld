<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tranlimit extends Model
{
    protected $table = 'tranlimits';
    protected $fillable = array( 'coin');
}
