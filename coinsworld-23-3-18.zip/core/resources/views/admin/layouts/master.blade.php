<!DOCTYPE html>

<html lang="en">
  
@include('admin.layouts.head')

    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

@include('admin.layouts.header')  
 
   
        <div class="clearfix"> </div>
       
@include('admin.layouts.container')      
    
 @include('admin.layouts.footer')            


@include('admin.layouts.scripts')            

    </body>

</html>