<!doctype html>
<html lang="en">
  <head>
    <title>{{$gset->webTitle}}</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" >
  </head>
  <body>
    <h1 style="margin:20px 70px auto;">Demo version. You can't change anything!</h1>
    <a href="{{url('/admin/home')}}"><h1 style="margin-left:100px;">Back to Home</h1></a>


  </body>
</html>
