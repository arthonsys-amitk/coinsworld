 <div class="page-footer">
            <div class="page-footer-inner"> Copyright &copy; <?php echo e($gset->webTitle); ?>

            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>