<div class="page-sidebar-wrapper">
            <!-- BEGIN SIDEBAR -->
            <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
            <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
<div class="page-sidebar navbar-collapse collapse">
    <!-- BEGIN SIDEBAR MENU -->
    <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
    <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
    <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
    <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
    <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
    <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
    <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
        <!-- DOC: To remove the sidebar toggler from the sidebar you just need to completely remove the below "sidebar-toggler-wrapper" LI element -->
        <li class="sidebar-toggler-wrapper hide">
            <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
            <div class="sidebar-toggler"> </div>
            <!-- END SIDEBAR TOGGLER BUTTON -->
        </li>
        <!-- DOC: To remove the search box from the sidebar you just need to completely remove the below "sidebar-search-wrapper" LI element -->
        <li class="sidebar-search-wrapper">
            <!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
            <!-- DOC: Apply "sidebar-search-bordered" class the below search form to have bordered search box -->
            <!-- DOC: Apply "sidebar-search-bordered sidebar-search-solid" class the below search form to have bordered & solid search box -->
            <form class="sidebar-search  " action="page_general_search_3.html" method="POST">
                <a href="javascript:;" class="remove">
                    <i class="icon-close"></i>
                </a>
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <span class="input-group-btn">
                        <a href="javascript:;" class="btn submit">
                            <i class="icon-magnifier"></i>
                        </a>
                    </span>
                </div>
            </form>
            <!-- END RESPONSIVE QUICK SEARCH FORM -->
        </li>
        <li class="nav-item  <?php if(request()->path() == 'admin/home'): ?> active open <?php endif; ?>">
            <a href="<?php echo e(route('admin')); ?>" class="nav-link nav-toggle">
                <i class="icon-home"></i>
                <span class="title">Dashboard</span>
                <span class="selected"></span>
            </a>
        </li>
        <li class="nav-item 
            <?php if(request()->path() == 'admin/gsettings'): ?> active open
                <?php elseif(request()->path() == 'admin/gsettings/email'): ?> active open
                <?php elseif(request()->path() == 'admin/gsettings/sms'): ?> active open
            <?php endif; ?>">
            <a href="javascript:;" class="nav-link nav-toggle">
                <i class="fa fa-cogs"></i>
                <span class="title">Website Control</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item <?php if(request()->path() == 'admin/gsettings'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(url('admin/gsettings')); ?>" class="nav-link ">
                        <i class="fa fa-cog"></i>
                        <span class="title">General Settings</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/gsettings/email'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(url('admin/gsettings/email')); ?>" class="nav-link ">
                        <i class="fa fa-envelope-o"></i>
                        <span class="title">Email Settings</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/gsettings/sms'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(url('admin/gsettings/sms')); ?>" class="nav-link ">
                        <i class="fa fa-commenting-o"></i>
                        <span class="title">SMS Settings</span>
                    </a>
                </li>
            </ul>
        </li>
        <li class="nav-item
            <?php if(request()->path() == 'admin/menu'): ?> active open
               <?php elseif(request()->path() == 'admin/menu/create'): ?> active open
               <?php elseif(request()->path() == 'admin/logo'): ?> active open
               <?php elseif(request()->path() == 'admin/slider'): ?> active open
               <?php elseif(request()->path() == 'admin/footer'): ?> active open
               <?php elseif(request()->path() == 'admin/social'): ?> active open
               <?php elseif(request()->path() == 'admin/contac'): ?> active open
               <?php elseif(request()->path() == 'admin/statistics'): ?> active open
               <?php elseif(request()->path() == 'admin/about'): ?> active open
               <?php elseif(request()->path() == 'admin/paymethod'): ?> active open
               <?php elseif(request()->path() == 'admin/service'): ?> active open
               <?php elseif(request()->path() == 'admin/testim'): ?> active open
            <?php endif; ?>">
            <a href="#" class="nav-link nav-toggle">
                <i class="fa fa-desktop"></i>
                <span class="title">Interface Control</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item <?php if(request()->path() == 'admin/menu'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('menu.index')); ?>" class="nav-link ">
                        <i class="fa fa-bars"></i>
                        <span class="title">Menus</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/logo'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('logo')); ?>" class="nav-link ">
                        <i class="fa fa-picture-o"></i>
                        <span class="title">Logo and Icon</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/slider'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('slider')); ?>" class="nav-link ">
                        <i class="fa fa-sliders"></i>
                        <span class="title">Slider Settings</span>
                    </a>
                </li>
                 <li class="nav-item <?php if(request()->path() == 'admin/about'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('about')); ?>" class="nav-link ">
                        <i class="fa fa-user"></i>
                        <span class="title">About US</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/service'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('service')); ?>" class="nav-link ">
                        <i class="fa fa-cogs"></i>
                        <span class="title">Services</span>
                    </a>
                </li>
                 <li class="nav-item <?php if(request()->path() == 'admin/paymethod'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('paymethod')); ?>" class="nav-link ">
                        <i class="fa fa-credit-card"></i>
                        <span class="title">Payment Method</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/testim'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('testim')); ?>" class="nav-link ">
                        <i class="fa fa-graduation-cap"></i>
                        <span class="title">Testimonial</span>
                    </a>
                </li>
                
                <li class="nav-item <?php if(request()->path() == 'admin/social'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('social')); ?>" class="nav-link ">
                        <i class="fa fa-share-square"></i>
                        <span class="title">Social Accounts</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/contac'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('contac')); ?>" class="nav-link ">
                        <i class="fa fa-id-card"></i>
                        <span class="title">Contact Information</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/statistics'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('statistics')); ?>" class="nav-link ">
                        <i class="fa fa-area-chart"></i>
                        <span class="title">Statistics</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/footer'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('footer')); ?>" class="nav-link ">
                        <i class="fa fa-list"></i>
                        <span class="title">Footer Content</span>
                    </a>
                </li>
               

            </ul>
        </li>
        <li class="nav-item
            <?php if(request()->path() == 'admin/charges'): ?> active open
               <?php elseif(request()->path() == 'admin/policy'): ?> active open
               <?php elseif(request()->path() == 'admin/package'): ?> active open
            <?php endif; ?>">
            <a href="#" class="nav-link nav-toggle">
                <i class="fa fa-id-card-o"></i>
                <span class="title">Company Policy</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item <?php if(request()->path() == 'admin/charges'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(url('admin/charges')); ?>" class="nav-link ">
                        <i class="fa fa-money"></i>
                        <span class="title">Charge / Commision</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/policy'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(url('admin/policy')); ?>" class="nav-link ">
                        <i class="icon-layers"></i>
                        <span class="title">Policy & Terms</span>
                    </a>
                </li>
                 <li class="nav-item <?php if(request()->path() == 'admin/packages'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('package')); ?>" class="nav-link ">
                        <i class="icon-layers"></i>
                        <span class="title">Packages</span>
                    </a>
                </li>
            </ul>
        </li>

        <li class="nav-item
            <?php if(request()->path() == 'admin/withdraw/requests'): ?> active open
              <?php elseif(request()->path() == 'admin/withdraw/lists'): ?> active open
              <?php elseif(request()->path() == 'admin/withdraw/refunded'): ?> active open
              <?php elseif(request()->path() == 'admin/wmethod'): ?> active open
            <?php endif; ?>">
            <a href="#" class="nav-link nav-toggle">
                <i class="fa fa-id-card-o"></i>
                <span class="title">Withdraw</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item <?php if(request()->path() == 'admin/wmethod'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('wmethod')); ?>" class="nav-link ">
                        <i class="fa fa-credit-card"></i>
                        <span class="title">Withdraw Methods</span>
                    </a>
                </li> 
                <li class="nav-item <?php if(request()->path() == 'admin/withdraw/requests'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('withdraw.requests')); ?>" class="nav-link ">
                        <i class="fa fa-money"></i>
                        <span class="title">Withdraw Requests</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/withdraw/lists'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('withdraw.lists')); ?>" class="nav-link ">
                        <i class="fa fa-list"></i>
                        <span class="title">Withdraw Log</span>
                    </a>
                </li>
                <li class="nav-item <?php if(request()->path() == 'admin/withdraw/refunded'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('withdraw.refundlog')); ?>" class="nav-link ">
                        <i class="fa fa-share"></i>
                        <span class="title">Refund Log</span>
                    </a>
                </li>
            </ul>
        </li>

         <li class="nav-item
            <?php if(request()->path() == 'admin/manage/userlog'): ?> active open
                <?php elseif(request()->path() == 'admin/manage/users'): ?> active open
            <?php endif; ?>">
            <a href="#" class="nav-link nav-toggle">
                <i class="fa fa-users"></i>
                <span class="title">User Management</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item <?php if(request()->path() == 'admin/manage/users'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('withdraw.users')); ?>" class="nav-link ">
                        <i class="fa fa-user"></i>
                        <span class="title">Users</span>
                    </a>
                </li> 
                <li class="nav-item <?php if(request()->path() == 'admin/manage/userlog'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('withdraw.userlog')); ?>" class="nav-link ">
                        <i class="fa fa-money"></i>
                        <span class="title">Users Transaction Log</span>
                    </a>
                </li> 
               
            </ul>
        </li>

        <li class="nav-item
            <?php if(request()->path() == 'admin/gateway'): ?> active open
                <?php elseif(request()->path() == 'admin/deposits'): ?> active open             
                <?php elseif(request()->path() == 'admin/deposits/requests'): ?> active open             
            <?php endif; ?>">
            <a href="#" class="nav-link nav-toggle">
                <i class="fa fa-money"></i>
                <span class="title">Deposit</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item <?php if(request()->path() == 'admin/gateway'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(url('admin/gateway')); ?>" class="nav-link ">
                        <i class="fa fa-credit-card"></i>
                        <span class="title">Deposit Method</span>
                    </a>
                </li> 
                 <li class="nav-item <?php if(request()->path() == 'admin/deposits/request'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('deposits.requests')); ?>" class="nav-link ">
                        <i class="fa fa-indent"></i>
                        <span class="title">Deposit Requests</span>
                    </a>
                </li>    
                <li class="nav-item <?php if(request()->path() == 'admin/deposits'): ?> active open <?php endif; ?>">
                    <a href="<?php echo e(route('deposits')); ?>" class="nav-link ">
                        <i class="fa fa-indent"></i>
                        <span class="title">Deposit List</span>
                    </a>
                </li>                   
            </ul>
        </li>

    </ul>

                    <!-- END SIDEBAR MENU -->
                    <!-- END SIDEBAR MENU -->
    </div>
                <!-- END SIDEBAR -->
 </div>