<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="portlet light bordered">
			<div class="portlet-title">
				<div class="caption">
					<i class="icon-settings"></i>
					<span class="caption-subject bold uppercase">Charge / Commision</span>
				</div>
			</div>
			<div class="portlet-body form">
				<form class="form-horizontal" action="<?php echo e(url('admin/charges')); ?>/<?php echo e($charges->id); ?>" method="POST" role="form">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('put')); ?>


					<div class="row">
						<div class="col-md-4 col-md-offset-1">
							<h5>Transfer Charge User To User</h5>
							<div class="form-body">
								<div class="form-group">
									
									<div class="input-group mb15">
										<input class="form-control input-lg" name="trancharge" value="<?php echo e($charges->trancharge); ?>" type="text">
										<span class="input-group-addon">%</span>
									</div>
								</div>
							</div>                    

						</div>

						<div class="col-md-4 col-md-offset-1">
							<h5>Withdraw Charge</h5>
							<div class="form-body">
							<div class="form-group">
							
								<div class="input-group mb15">
									<input class="form-control input-lg" name="withcrg" value="<?php echo e($charges->withcrg); ?>" type="text">
									<span class="input-group-addon">%</span>
								</div>
							</div>
						</div>
						</div>
					</div>

					<div class="row">
						<hr/>
						<div class="col-md-4 col-md-offset-1">
							<h5>UPGRADE Charge</h5>
							<div class="form-body">
								<div class="form-group">
									<div class="input-group mb15">
										<input class="form-control input-lg" name="upgcrg" value="<?php echo e($charges->upgcrg); ?>" type="text">
										<span class="input-group-addon"><?php echo e($gset->curSymbol); ?></span>
									</div>
								</div>  
							</div>
						</div>

						<div class="col-md-4 col-md-offset-1">
							<h5>UPGRADE Commision To TREE</h5>
							<div class="form-body">
								<div class="form-group">
									<div class="input-group mb15">
										<input class="form-control input-lg" name="uptree" value="<?php echo e($charges->uptree); ?>" type="text">
										<span class="input-group-addon"><?php echo e($gset->curSymbol); ?></span>
									</div>
								</div>  
							</div>
						</div>
					</div>

					<div class="row">
						<hr/>
						<div class="col-md-4 col-md-offset-4">
							<h5>UPGRADE Commision To Sponsor</h5>
							<div class="form-body">
								<div class="form-group">
									<div class="input-group mb15">
										<input class="form-control input-lg" name="upsponsor" value="<?php echo e($charges->upsponsor); ?>" type="text">
										<span class="input-group-addon"><?php echo e($gset->curSymbol); ?></span>
								</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<hr/>
						<div class="col-md-4 col-md-offset-4">
							<button class="btn btn-lg btn-success">Update</button>
						</div>
					</div>
				</form>
			</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>