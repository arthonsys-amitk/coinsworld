<?php $__env->startSection('content'); ?>
<?php echo $__env->make('front.layouts.ballscript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="admin-two dashboard">
<!--Start Container-->
<div class="container">
<!--Start Admin Wrap-->
<div class="admin-two-wrap" style="padding: 0px;">
<!--Start Admin Wrap Row-->
<div class="row">
<!--Start Admin Menu Col-->
<!--Start Admin Content Col-->
<div class="col-md-12">
<!--Start Admin Content-->
<div class="admin-two-cont">
<!--Start Dashboard-->
<div class="admin-dashboard">             
<div class="row">
      <div class="col-md-12">
          <div class="panel panel-warning">
      <div class="panel-heading text-center">
        <h1><?php echo e($game->name); ?></h1>
        <h4>Time Remaining: <span id="getting-started"></span></h4>
         <p id="date" style="display: none;"><?php echo e($date); ?></p>
            <script type="text/javascript">
                var date = $('#date').text();
              $("#getting-started")
              .countdown(date, function(event) {
                $(this).text(
                  event.strftime('%D days %H:%M:%S')
                );
              });
            </script>
      </div>
    <div class="panel-body">
      <div class="col-md-6">
        <h3 style="text-align: center; color:#ff9900;">Click on a Ball to Invest</h3>
        <div class="cc22" id="sGame">
                  <img src="<?php echo e(asset('assets/images/seventrade/1.png')); ?>" class="box" id="a" value="1">
                  <img src="<?php echo e(asset('assets/images/seventrade/2.png')); ?>" class="box" id="b" value="2">
                  <img src="<?php echo e(asset('assets/images/seventrade/3.png')); ?>" class="box" id="c" value="3">
                  <img src="<?php echo e(asset('assets/images/seventrade/4.png')); ?>" class="box" id="d" value="4">
                  <img src="<?php echo e(asset('assets/images/seventrade/5.png')); ?>" class="box" id="e" value="5">
                  <img src="<?php echo e(asset('assets/images/seventrade/6.png')); ?>" class="box" id="f" value="6">
                  <img src="<?php echo e(asset('assets/images/seventrade/7.png')); ?>" class="box" id="g" value="7">
                  <img src="<?php echo e(asset('assets/images/seventrade/8.png')); ?>" class="box" id="h" value="8">
                  <img src="<?php echo e(asset('assets/images/seventrade/9.png')); ?>" class="box" id="i" value="9">
                </div>
      </div>
      <div class="col-md-6">
        <form method="POST" action="<?php echo e(route('play.invest')); ?>" style="margin-top: 30%">
          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="game_id" value="<?php echo e($game->id); ?>">
          <table class="table table-responsive bid-form" style="display: none;">
            <tr>
              <td>Selected Ball No.</td>
              <td>Your Current Balance</td>
            </tr>
            <tr>
              <td>
                <input type="text" class="form-control" name="ball" id="sssss" value="" readonly>
              </td>
              <td>
                <?php echo e(Auth::user()->balance); ?> <?php echo e($gset->curSymbol); ?>

              </td>
            </tr>
          </table>
          <div class="form-group">
            <div class="input-group">
              <input type="text" class="form-control" id="amount" name="amount" placeholder="Enter Investment Amount">
              <span class="input-group-addon"><?php echo e($gset->curSymbol); ?></span>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-lg btn-success btn-block" >Invest on Ball</button>
          </div>

        </form>
      </div>
       
    </div>
        </div> 
      </div>               
            
<!--End Dashboard-->
</div>
<!--End Admin Content-->
</div>
<!--End Admin Content Col-->
</div>
<!--End Admin Wrap-->
</div>
</div>
</div>
</div>
</section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>