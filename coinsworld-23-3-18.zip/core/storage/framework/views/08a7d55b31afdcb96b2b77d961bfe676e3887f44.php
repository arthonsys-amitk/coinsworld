<?php $__env->startSection('content'); ?>
<section class="section-padding about-us-page">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="well">
				<form role="form" method="POST" action="<?php echo e(route('withdraw.req')); ?>" >
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="wdid" value="wd<?php echo e(time()); ?>">
					<input type="hidden" name="wdmethod_id" 
					value="<?php echo e($method->id); ?>">
					<input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
					<input type="hidden" name="status" value="0">
					<div class="form-group">
						<p>Requested for: <b><?php echo e($withdraw['amount']); ?> </b> <?php echo e($gsettings->curSymbol); ?></p>
						<input type="hidden" class="form-control" value="<?php echo e($withdraw['amount']); ?>" id="amount" name="amount" >
					</div>
					<p>Current Balance: <b><?php echo e(Auth::user()->balance); ?></b> <?php echo e($gsettings->curSymbol); ?></p>
					<p>Balance After this Withdraw: <b><?php echo e($balance); ?></b> <?php echo e($gsettings->curSymbol); ?></p>
					<div class="form-group">
						<p>Details: <?php echo e($withdraw['details']); ?> </p>
						<textarea class="form-control"  id="details" name="details" name="details">					
						</textarea>
					</div>
					<button type="submit" class="btn btn-primary">Withdraw</button>
				</form>
			</div>
			</div>
			


		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>