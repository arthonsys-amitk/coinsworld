<?php $__env->startSection('content'); ?>
<section class="admin-two dashboard">
<!--Start Container-->
<div class="container">
<!--Start Admin Wrap-->
<div class="admin-two-wrap">
<!--Start Admin Wrap Row-->
<div class="row">
<!--Start Admin Menu Col-->
<?php echo $__env->make('front.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Start Admin Content Col-->
<div class="col-md-9">
<!--Start Admin Content-->
<div class="admin-two-cont">
<!--Start Dashboard-->
<div class="admin-dashboard">       	
		<div class="row">
<!--Start Visitors Country-->
<div class="admin-vistitor-country">
<div class="col-md-12">



<form action="https://perfectmoney.is/api/step1.asp" method="POST" id="myform">
<input type="hidden" name="PAYEE_ACCOUNT" value="<?php echo e($perfect['value1']); ?>">
<input type="hidden" name="PAYEE_NAME" value="<?php echo e($gset->webTitle); ?>">
<input type='hidden' name='PAYMENT_ID' value='<?php echo e($perfect['track']); ?>'>
<input type="hidden" name="PAYMENT_AMOUNT"  value="<?php echo e($perfect['amount']); ?>">
<input type="hidden" name="PAYMENT_UNITS" value="USD">
<input type="hidden" name="STATUS_URL" value="<?php echo e(route('ipn.perfect')); ?>">
<input type="hidden" name="PAYMENT_URL" value="<?php echo e(route('home')); ?>">
<input type="hidden" name="PAYMENT_URL_METHOD" value="POST">
<input type="hidden" name="NOPAYMENT_URL" value="<?php echo e(route('home')); ?>">
<input type="hidden" name="NOPAYMENT_URL_METHOD" value="POST">
<input type="hidden" name="SUGGESTED_MEMO" value="<?php echo e(Auth::user()->username); ?>">
<input type="hidden" name="BAGGAGE_FIELDS" value="IDENT"><br>
</form>




</div>	
<!--End Dashboard-->
</div>
<!--End Admin Content-->
</div>
<!--End Admin Content Col-->
</div>
<!--End Admin Wrap-->
</div>
</div>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
document.getElementById("myform").submit();
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>