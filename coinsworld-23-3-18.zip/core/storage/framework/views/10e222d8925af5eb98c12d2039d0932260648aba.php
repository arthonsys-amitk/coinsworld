 <nav class="main-menu nav-fixed">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>"
                          alt="Logo Image Will Be Here" style="max-width:280px; max-height: 60px;" ></a>
                    </div>
                </div>
<div class="col-md-8 text-right">
<ul id="menu-bar">  
    <li><a href="<?php echo e(url('register')); ?>">SIGN UP</a></li>
</ul>
                </div>
            </div>
        </div>
    </nav>



