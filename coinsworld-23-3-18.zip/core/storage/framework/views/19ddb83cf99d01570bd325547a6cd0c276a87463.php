<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="portlet light bordered">
            <div class="portlet-title">
              <div class="col-md-6">
                 <div class="caption">
                    <i class="icon-list font-blue"></i>
                    <span class="caption-subject font-green bold uppercase">User information</span> 
                      <h3><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h3> 
                      <h5>Username: <?php echo e($user->username); ?></h5>
                      <a href="<?php echo e(route('email',$user->id)); ?>" class="btn btn-primary" style="margin-bottom:10px;">Send Email</a>
                </div>
              </div>
              <div class="col-md-6">
                  <div class="well">
                      <div class="btn-group">
                        <button type="button" class="btn btn-success"  data-toggle="modal" data-target="#addBalance">Manage Balance</button>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#updateStatus">Change Status</button>
                      </div>                  
                    </div>
              </div>
               
            </div>
            <div class="portlet-body">
             <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="dashboard-stat blue">
                        <div class="visual">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                              <?php if($user->refid != '0'): ?>
                              <?php echo e($user->referby-> firstname); ?> <?php echo e($user->referby-> lastname); ?>

                              <?php else: ?>
                                No Reference
                              <?php endif; ?>
                            </div>
                            <div class="desc"> Refered By</div>
                        </div>
                    </div>
                </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="dashboard-stat green">
                    <div class="visual">
                        <i class="fa fa-money"></i>
                    </div>
                    <div class="details">
                        <div class="number">
                            <span data-counter="counterup" data-value="<?php echo e(number_format(floatval($user->balance), $gset->decimalPoint, '.', '')); ?>">0</span> <?php echo e($gset-> curSymbol); ?> </div>
                            <div class="desc">Balance</div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="panel panel-primary">
                      <div class="panel-heading">Status</div>
                      <div class="panel-body">
                        <?php if($user->status == '1'): ?> Active
                        <?php elseif($user->status == '0'): ?> Deactive
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
                <div class="col-md-6">
                   <div class="panel panel-info">
              <div class="panel-heading">Refered Users</div>
                <div class="panel-body">
                    <table class="table table-responsive table-stripped">
                      <tr>
                        <th>
                           Name
                        </th>
                         <th>
                          Date of Join
                        </th>
                      </tr>
                        <?php $__currentLoopData = $refers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($ref-> position == "1" ? 'warning' : 'info'); ?>">
                           <td>
                            <a href="<?php echo e(route('user.single', $ref->id)); ?>">
                              <?php echo e($ref-> firstname); ?>

                            </a>
                          </td>                       
                           <td>
                            <?php echo e($ref-> created_at); ?>

                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                      </table>    
                </div>
          </div>   
               </div>
               <div class="col-md-6">
                     <div class="panel panel-warning">
              <div class="panel-heading">9 Bal Game Investments</div>
                <div class="panel-body">
                    <table class="table table-responsive table-stripped">
                      <tr>
                        <th>
                           Game Name
                        </th>
                         <th>
                          Ball No
                        </th>
                        <th>
                          Amount
                        </th>
                      </tr>
                        <?php $__currentLoopData = $invests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <?php echo e($inv->game->name); ?>

                          </td>                       
                           <td>
                            <?php echo e($inv->ball); ?>

                          </td>
                           <td>
                            <?php echo e($inv->amount); ?> <?php echo e($gset->curSymbol); ?>

                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                      </table>    
                </div>
          </div>   
              </div>
         
                </div>
              
               </div>
               
          
        </div>
        <div class="row">
          <div class="panel panel-primary">
              <div class="panel-heading">Latest Transactions</div>
                <div class="panel-body">
                    <table class="table table-responsive table-stripped">
                      <tr>
                        <th>
                          Transaction ID
                        </th>
                        <th>
                          Amount
                        </th>
                         <th>
                          Operation
                        </th>
                        <th>
                          Current Balance
                        </th>
                        <th>
                          Description
                        </th>
                         <th>
                          Processed at
                        </th>
                      </tr>
                        <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($tran->flag == "1" ? 'success' : 'danger'); ?>">
                           <td>
                            <?php echo e($tran-> trxid); ?>

                          </td>
                          <td>
                            <?php echo e(number_format(floatval($tran-> amount), $gset->decimalPoint, '.', '')); ?> <?php echo e($gset-> curSymbol); ?>

                          </td>
                            <td>
                           <?php echo e($tran->flag == "1" ? 'Credited' : 'Debited'); ?>

                          </td>
                          <td>
                            <?php echo e(number_format(floatval($tran->balance), $gset->decimalPoint, '.', '')); ?>      
                          </td> 
                          <td>
                            <?php echo e($tran-> desc); ?>

                          </td>
                           <td>
                            <?php echo e($tran-> created_at); ?>

                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                      </table>    
                </div>
          </div>
          
        </div>
        </div>
    </div>
</div>
</div>


<!-- Manage Balance -->
   <div id="addBalance" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Add/Substract Balance</h4>
            </div>
        <div class="modal-body">
                 <form role="form" method="POST" action="<?php echo e(route('user.balance', $user->id)); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('put')); ?>

                <div class="form-group">
                  <label>Operation</label>
                  <input data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" data-on="Add Balance" data-off="Substract Balance" type="checkbox" value="1" name="status" > 
                </div>
                <div class="form-group">
                    <label>Amount</label>
                    <input type="text" name="amount" class="form-control">
                </div>
                <div class="form-group">
                    <label>Message</label>
                    <input type="text" name="message" class="form-control" />
                </div>
                
            </div>
              <div class="modal-footer">
                            <button type="button" class="btn btn-default  pull-left" data-dismiss="modal">Close</button>
                             <button type="submit" class="btn btn-primary  pull-right">Update</button>
                        </div>
                  </form>
            


        </div>
    </div>
</div>

<!-- Update Status -->
            <div class="modal fade" id="updateStatus" role="dialog">
                <div class="modal-dialog">

                  <!-- Modal content-->
                  <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">Update Status</h4>
                        </div>

                        <div class="modal-body">
                             <form role="form" method="POST" action="<?php echo e(route('user.status', $user->id)); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <div class="form-group">
                                <label>Change User Status</label>
                                 <input data-toggle="toggle" data-onstyle="success" data-offstyle="danger" data-width="100%" data-on="Active" data-off="Deactive" type="checkbox" value="1" name="status" <?php echo e($user->status == "1" ? 'checked' : ''); ?>> 
                            </div>                           
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default  pull-left" data-dismiss="modal">Close</button>
                             <button type="submit" class="btn btn-primary  pull-right">Update</button>
                        </div>
                  </form>
               
                    </div>
                </div>
            </div>

  <!-- Update Package -->
            <div class="modal fade" id="updatepack" role="dialog">
                <div class="modal-dialog">

                  <!-- Modal content-->
                  <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">Update Package</h4>
                        </div>

                        <div class="modal-body">
                             <form role="form" method="POST" action="<?php echo e(route('user.package', $user->id)); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <div class="form-group">
                                <label>Change User Package</label>
                                <select class="form-control" name="package_id">
                                  <option value="1">Free</option>
                                  <option value="2">Premium</option>
                                </select> 
                            </div>                           
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default  pull-left" data-dismiss="modal">Close</button>
                             <button type="submit" class="btn btn-primary  pull-right">Update</button>
                        </div>
                  </form>
               
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>