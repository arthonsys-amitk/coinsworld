<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-list font-blue"></i>
                        <span class="caption-subject font-green bold uppercase">Payment Method Section</span>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="row">
                    <form role="form" method="POST" action="<?php echo e(route('payin.update',$payin->id)); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <div class="form-body">

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label><h3>Heading</h3></label>
                                            <input type="text" class="form-control input-lg" value="<?php echo e($payin->heading); ?>" name="heading" >
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label><h3>Details</h3></label>
                                           <textarea name="details" class="form-control" rows="3">
                                               <?php echo e($payin->details); ?>

                                            </textarea>
                                        </div>
                                    </div>
                            </div>
                            <div class="form-actions right">
                                <button type="submit" class="btn blue btn-lg">Update</button>
                            </div>
                        </form>
                     </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-list font-blue"></i>
                        <span class="caption-subject font-green bold uppercase">Payment Methods</span>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="row">
                        <form role="form" method="POST" action="<?php echo e(route('paymethod.store')); ?>" enctype="multipart/form-data" class="form-inline">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-body">

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <span class="btn green fileinput-button">
                                                <i class="fa fa-plus"></i>
                                            <span> Upload Payment Method Logo (300x300 px)</span>
                                            <input type="file" name="payment" class="form-control input-lg"> </span>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn blue btn-lg">Save</button>
                                        </div>
                                    </div>
                            </div>
                        </form>
                     </div>
                      <div class="row">
                        <div class="col-md-12">
                            <hr/>
                            <div class="panel panel-primary">
                              <div class="panel-heading">Payment Methods</div>
                              <div class="panel-body">
                            <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2 col-md-offset-1 well">
                                     <img src="<?php echo e(asset('assets/images/paymethod')); ?>/<?php echo e($pay->payment); ?>" class="img-responsive" width="100%" >
                                     <hr/>
                                     <a class="btn btn-circle  btn-danger"  href="<?php echo e(route('paymethod.destroy', $pay->id)); ?>" data-toggle="confirmation"  data-title="Are You Sure?" data-content="Delete This Payment Icon?">
                                        <i class="fa fa-trash"></i> Delete
                                </a>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>