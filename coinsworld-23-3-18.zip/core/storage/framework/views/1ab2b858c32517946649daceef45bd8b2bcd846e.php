<?php $__env->startSection('content'); ?>
<style>
#chartdiv {
  width : 100%;
  height  : 300px;
}                  
</style>

<!-- Chart code -->
<script>
var chartData = generateChartData();

var chart = AmCharts.makeChart("chartdiv", {
    "type": "serial",
    "theme": "light",
    "marginRight": 80,
    "dataProvider": chartData,
    "valueAxes": [{
        "position": "left",
        "title": "Price History"
    }],
    "graphs": [{
        "id": "g1",
        "fillAlphas": 0.4,
        "valueField": "visits",
         "balloonText": "<div style='margin:5px; font-size:19px;'><b>$ [[value]]</b></div>"
    }],
    "chartScrollbar": {
        "graph": "g1",
        "scrollbarHeight": 20,
        "backgroundAlpha": 0,
        "selectedBackgroundAlpha": 0.1,
        "selectedBackgroundColor": "#888888",
        "graphFillAlpha": 0,
        "graphLineAlpha": 0.5,
        "selectedGraphFillAlpha": 0,
        "selectedGraphLineAlpha": 1,
        "autoGridCount": true,
        "color": "#333"
    },
    "chartCursor": {
        "categoryBalloonDateFormat": "JJ:NN, DD MMMM",
        "cursorPosition": "mouse"
    },
    "categoryField": "date",
    "categoryAxis": {
        "minPeriod": "mm",
        "parseDates": true
    },
    "export": {
        "enabled": true,
         "dateFormat": "YYYY-MM-DD HH:NN:SS"
    }
});

chart.addListener("dataUpdated", zoomChart);

function zoomChart() {

    chart.zoomToIndexes(chartData.length - 250, chartData.length - 100);
}

function generateChartData() {
    var chartData = [];

<?php $__currentLoopData = $allprice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




var newDate = new Date('<?php echo e($pri->created_at); ?>');


        chartData.push({
            date: newDate,
            visits: <?php echo e($pri->price); ?>

        });

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    return chartData;
}
</script>

<section class="section-padding " style="background-color: #f2f2f2; margin-top: 40px;">
<div class="container">

<div class="row section-padding">
<div class="col-md-5">
<div class="panel panel-primary">
<div class="panel-heading">
SIGN IN
</div>
<div class="panel-body">
    <form method="POST" action="<?php echo e(route('postLogin')); ?>">
        <?php echo e(csrf_field()); ?>

<div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
<label for="username" >Username</label>
<div class="input-group">
  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
  <input type="text" class="form-control input-sz" name="username" id="username"  placeholder="Enter Username" required />
<?php if($errors->has('username')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('username')); ?></strong>
</span>
<?php endif; ?>
</div>

</div>

        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
<label for="password">Password</label>
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-lock" aria-hidden="true"></i></span>
<input type="password" class="form-control input-sz" name="password" id="password" required />
<?php if($errors->has('password')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('password')); ?></strong>
</span>
<?php endif; ?>
</div>
</div>
<div class="form-group">

<div class="form-group ">
  <button type="submit" class="submit-btn btn btn-lg btn-block login-button">Log In</button>
</div>

<a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
Forgot Your Password?
</a>
</div>
</form>
</div>
</div>
</div>

<div class="col-md-7">
    <div class="panel panel-primary">

             
        <div class="panel-body">
            <h2 class="blfont">BTC = $<?php echo e(rtrim(number_format(floatval($currentRate) , $gset->decimalPoint, '.', ''),'0')); ?> <span class="ncrate pull-right"> <?php echo e($gset->curCode); ?> = $<?php echo e(rtrim(number_format(floatval($price->price) , $gset->decimalPoint, '.', ''),'0')); ?> </span></h2>
             <div class="col-md-12" id="chartdiv"></div> 
        </div>
    </div>
</div>
             </div>
         </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>