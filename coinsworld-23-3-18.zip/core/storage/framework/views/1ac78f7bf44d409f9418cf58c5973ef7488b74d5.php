<?php $__env->startSection('content'); ?>
<!--Start Admin Section-->
<section class="admin-two dashboard">
<!--Start Container-->
<div class="container">
<!--Start Admin Wrap-->
<div class="admin-two-wrap">
<!--Start Admin Wrap Row-->
<div class="row">
<!--Start Admin Menu Col-->
<?php echo $__env->make('front.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--End Admin Menu Col-->

<!--Start Admin Content Col-->
<div class="col-md-9">
<!--Start Admin Content-->
<div class="admin-two-cont">
<!--Start Dashboard-->
<div class="admin-dashboard">
<!--Start Row-->
<div class="row">
<!--Start Overview-->
<div class="db-overview">
<!--Start Overview Item Col-->
<div class="col-sm-3">
  <!--Start Overview Item-->
  <div class="overview-item <?php echo e(Auth::User()->sid == '11' ? 'two': 'one'); ?>">
      <h3 class="text-center"><?php echo e(Auth::User()->firstname); ?> <?php echo e(Auth::User()->lastname); ?></h3>
      <p class="text-center"><i class="fa fa-user"></i></p>
      <p class="text-center"><?php echo e(Auth::User()->package_id == '2' ? 'Premium': 'Free'); ?></p>
  </div>
  <!--End Overview Item-->
</div>
<!--End Overview Item Col-->

<!--Start Overview Item Col-->
<div class="col-sm-3">
  <!--Start Overview Item-->
  <div class="overview-item three">
      <h3 class="text-center">Balance</h3>
      <p class="text-center"><i class="fa fa-shopping-bag"></i></p>
      <p class="text-center"><?php echo e(number_format(floatval(Auth::user()->balance) , $gset->decimalPoint, '.', '')); ?> 
<?php echo e($gset->curSymbol); ?></p>
  </div>
  <!--End Overview Item-->
</div>
<!--End Overview Item Col-->

<!--Start Overview Item Col-->
<div class="col-sm-3">
  <!--Start Overview Item-->
  <div class="overview-item three">
      <h3 class="text-center">Refered User</h3>
      <p class="text-center"><i class="fa fa-share"></i></p>
      <p class="text-center"><?php echo e(count($refers)); ?> Person</p>
  </div>
  <!--End Overview Item-->
</div>
<!--End Overview Item Col-->

<!--Start Overview Item Col-->
<div class="col-sm-3">
  <!--Start Overview Item-->
  <div class="overview-item <?php echo e(Auth::User()->sid == '11' ? 'four': 'one'); ?>">
      <h3 class="text-center">Status</h3>
      <p class="text-center"><i class="fa fa-joomla"></i></p>
      <p class="text-center"><?php echo e(Auth::User()->sid == '11' ? 'Referal Limit Exceed': 'Referable'); ?></p>
  </div>
  <!--End Overview Item-->
</div>
<!--End Overview Item Col-->
</div>
<!--End Overview-->
</div>
<!--End Row-->
<div class="row">
<!--Refer -->
<div class="db-overview">
<div class="panel <?php echo e(Auth::User()->sid == '11' ? 'panel-danger': 'panel-info'); ?> ">
<div class="panel-heading">My Referal Link:</div>
<div class="panel-body">

<h3><code><?php echo e(Auth::User()->sid == '11' ? 'Exceed Referal Limit': $rlink); ?></code></h3>
</div>
</div>                     
</div>
</div>



<!--Start Row-->
<div class="row">
<!--Start Visitors Country-->
<div class="admin-vistitor-country">
<div class="col-md-12">
  <div class="visitor-country">
      <h3 class="text-bold text-center">Transactions</h3>
      <div class="table-responsive">
          <table class="table table-responsive">
              <thead>
                  <tr>
                    
              <th>
                Transaction ID
              </th>
              <th>
                Amount
              </th>
              <th>
                Operation
              </th>
              <th>
                Balance
              </th>
              <th>
                Description
              </th>
              <th>
                Processed at
              </th>
           

                  </tr>
              </thead>
              <tbody>
   <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="<?php echo e($tran->flag == "1" ? 'success' : 'danger'); ?>">
<td>
<?php echo e($tran-> trxid); ?>

</td>
<td>
<?php echo e(number_format(floatval($tran-> amount), $gset->decimalPoint, '.', '')); ?> <?php echo e($gset-> curSymbol); ?>

</td>
<td>
<?php echo e($tran->flag == "1" ? 'Debited' : 'Credited'); ?>

</td>
<td>
<?php echo e(number_format(floatval($tran->balance), $gset->decimalPoint, '.', '')); ?>      
</td> 
<td>
<?php echo e($tran-> desc); ?>

</td>
<td>
<?php echo e($tran-> created_at); ?>

</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
<?php echo $trans->render(); ?>
              </tbody>
              <tfoot>
                  <tr>
                      <th>
                Transaction ID
              </th>
              <th>
                Amount
              </th>
              <th>
                Operation
              </th>
              <th>
                Balance
              </th>
              <th>
                Description
              </th>
              <th>
                Processed at
              </th>
           
                  </tr>
              </tfoot>
          </table>
      </div>
  </div>
</div>
</div>
<!--End Visitors Country-->
</div>
<!--End Row-->
</div>
<!--End Dashboard-->
</div>
<!--End Admin Content-->
</div>
<!--End Admin Content Col-->
</div>
<!--End Admin Wrap-->
</div>
</div>
<!--End Container-->

</section>
<!--End Admin Section-->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>