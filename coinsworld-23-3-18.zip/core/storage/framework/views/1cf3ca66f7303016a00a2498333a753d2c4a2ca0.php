<?php $__env->startSection('content'); ?>
<section class="admin-two dashboard">
<!--Start Container-->
<div class="container">
<!--Start Admin Wrap-->
<div class="admin-two-wrap">
<!--Start Admin Wrap Row-->
<div class="row">
<!--Start Admin Menu Col-->
<!--Start Admin Content Col-->
<div class="col-md-12">
<!--Start Admin Content-->
<div class="admin-two-cont">
<!--Start Dashboard-->
<div class="admin-dashboard">             
<div class="row">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h1 style="color:#fff;">My Investments on 9 Ball Game</h1>
        </div>
        <div class="panel-body">
          <table class="table table-striped">
              <thead>
                <tr>
                  <th>Game Name</th>
                  <th>Ball No</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $invests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($invest->game->name); ?></td>
                  <td><?php echo e($invest->ball); ?></td>
                  <td><?php echo e($invest->amount); ?> <?php echo e($gset->curSymbol); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
      </div>
            
<!--End Dashboard-->
</div>
<!--End Admin Content-->
</div>
<!--End Admin Content Col-->
</div>
<!--End Admin Wrap-->
</div>
</div>
</section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>