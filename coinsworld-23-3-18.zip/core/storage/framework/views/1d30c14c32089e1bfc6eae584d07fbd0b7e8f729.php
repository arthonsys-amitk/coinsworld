<?php $__env->startSection('content'); ?>
<section class="admin-two dashboard">
<!--Start Container-->
<div class="container">
<!--Start Admin Wrap-->
<div class="admin-two-wrap">
<!--Start Admin Wrap Row-->
<div class="row">
<!--Start Admin Menu Col-->
<!--Start Admin Content Col-->
<div class="col-md-12">
<!--Start Admin Content-->
<div class="admin-two-cont">
<!--Start Dashboard-->
<div class="admin-dashboard">             
      <div class="row">
            <div class="panel panel-success">
<div class="panel-heading">
<h1>My Prize Bonds</h1>
</div>
<div class="panel-body">
<?php $__currentLoopData = $mybonds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mbond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-3">
      <div class="panel panel-warning">
            <div class="panel-heading text-center" ><?php echo e($mbond->bond->name); ?></div>
            <div class="panel-body">
                  <div class="well">
                      <h2><?php echo e($mbond->bond->price); ?> <?php echo e($gset->curSymbol); ?></h2>
                  </div>
                   <img src="<?php echo e(asset('assets/images/money.png')); ?>" width="100%" class="img-responsive">
                  <div class="well">
                       <h4><?php echo e($mbond->bond->code); ?></h4>
                  </div>
                                    
            </div>
            <div class="panel-footer"><div class="form-group ">
                  <button type="button" class="submit-btn btn btn-lg btn-block login-button" data-toggle="modal" data-target="#bond<?php echo e($mbond->id); ?>">Release</button>
            </div></div>
      </div>
</div>


<div class="modal fade" id="bond<?php echo e($mbond->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
            <div class="modal-content">
                  <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e($mbond->bond->name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                        </button>
                  </div>
                  <div class="modal-body">
                        <h2>Are You Sure?</h2>
                        <h3> You are Relasing this prize Bond</h3>
                        <form role="form" method="post" action="<?php echo e(route('release')); ?>" >
                              <?php echo e(csrf_field()); ?>

                              <input type="hidden" name="bondid" value="<?php echo e($mbond->bond->id); ?>">
                              <input type="hidden" name="soldid" value="<?php echo e($mbond->id); ?>">
                              <button type="submit" class="btn btn-primary btn-lg btn-block">Confirm Release</button>
                        </form>
                  </div>
                  <div class="modal-footer">
                        <button type="button" class="btn btn-secondary pull-left" data-dismiss="modal">Close</button>
                  </div>

            </div>
      </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
</div>
</div>
<!--End Dashboard-->
</div>
<!--End Admin Content-->
</div>
<!--End Admin Content Col-->
</div>
<!--End Admin Wrap-->
</div>
</div>
</section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>