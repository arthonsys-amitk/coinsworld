<!DOCTYPE html>
<html lang="">
    <!-- Head -->
    <?php echo $__env->make('front.layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Head -->
    <body >
    <!--Theme Color Start-->
    
    <!--Preloader start-->
    <?php echo $__env->make('front.layouts.preloader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
    <!--Preloader end-->
    <div class="site"><!--for boxed Layout start-->

    <!--Scroll to top start-->
    <div class="scroll-to-top">
        <a href=""><i class="fa fa-caret-up"></i></a>
    </div><!--Scroll to top end-->
<!--mobile logo -->
    <div class="mobile-logo">
        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="Logo Image Will Be Here"></a>
    </div>

    <!--main menu start-->
    <?php echo $__env->make('front.layouts.mainmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <!--main menu end-->

       <?php echo $__env->make('front.layouts.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
   <?php echo $__env->yieldContent('content'); ?>
     
    <?php echo $__env->make('front.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--jquery script load-->
    <?php echo $__env->make('front.layouts.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>




















