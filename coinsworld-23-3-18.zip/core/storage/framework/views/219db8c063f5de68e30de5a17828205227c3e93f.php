  <script src="<?php echo e(asset('assets/front/js/jquery.js')); ?>"></script>
         <!--Owl carousel script load-->
		<script src="<?php echo e(asset('assets/front/js/owl.carousel.min.js')); ?>"></script>
        <!--Bootstrap v3 script load here-->
        <script src="<?php echo e(asset('assets/front/js/bootstrap.min.js')); ?>"></script>
        <!--Slick Nav Js File Load-->
        <script src="<?php echo e(asset('assets/front/js/jquery.slicknav.min.js')); ?>"></script>
        <!-- rangeslider Js File Load-->
        <script src="<?php echo e(asset('assets/front/js/jquery-asRange.min.js')); ?>"></script>
         <!--Main js file load-->
        <script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>

         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

 <!-- NicEditor -->
        <script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
        <script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>

<script>
    $(document).ready(function(){
        var date_input=$('input[name="date"]'); //our date input has the name "date"
        var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
        date_input.datepicker({
            format: 'mm/dd/yyyy',
            container: container,
            todayHighlight: true,
            autoclose: true,
        })
    })
</script>

<!-- admin -->

   <!--Conter JS-->
    <script type="text/javascript" src="<?php echo e(asset('assets/front/admin/js/waypoints.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/front/admin/js/jquery.counterup.min.js')); ?>"></script>

     <!--Form Select Option JS-->
    <script type="text/javascript" src="<?php echo e(asset('assets/front/admin/js/select2.min.js')); ?>"></script>
    <!--Pie Chart JS-->
    <script type="text/javascript" src="<?php echo e(asset('assets/front/admin/js/pie-chart.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/front/admin/js/pie-chart-1.js')); ?>"></script>
    <!-- Main JS -->
    <script type="text/javascript" src="<?php echo e(asset('assets/front/admin/js/main.js')); ?>"></script>