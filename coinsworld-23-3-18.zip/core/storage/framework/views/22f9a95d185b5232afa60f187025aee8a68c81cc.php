<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- BEGIN EXAMPLE TABLE PORTLET-->
        <div class="portlet light bordered">
            <div class="portlet-title">
                <div class="caption font-dark">
                    <i class="icon-settings font-dark"></i>
                    <span class="caption-subject bold uppercase"> Deposit List</span>
                </div>

            </div>
            <div class="portlet-body">

                <table class="table table-striped table-bordered table-hover order-column" id="sample_1">
                <thead>
                    <tr>
                      	<th>
                            Deposit ID 
                        </th>
                        <th>
                            User
                        </th>
                        <th>
                            Amount
                        </th>
                       	<th>
                       		Method
                       	</th>
                        <th>
                            Processed on
                        </th>
                  	 </tr>
                </thead>
                <tbody>
		 	<?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                     	<td>
                        	<?php echo e($dep->trxid); ?>  	
                        </td>
                        <td>
                          <a href="<?php echo e(route('user.single', $dep->user->id)); ?>">
                             <?php echo e($dep->user->firstname); ?>

                             <?php echo e($dep->user->lastname); ?> 
                          </a>
                        </td> 
                        <td>
                             <?php echo e($dep->amount); ?> <?php echo e($gset->curSymbol); ?>

                        </td>
                        <td>
                        	<img src="<?php echo e(asset('assets/images/gateway')); ?>/<?php echo e($dep->gateway->gateimg); ?>" width="50">
                        </td>
                        <td>
                        	<?php echo e($dep->updated_at); ?>

                        </td>
                      </tr>
 			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
 			<tbody>
           </table>
        </div>
			
				</div><!-- row -->
			</div>
		</div>
	</div>		
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>