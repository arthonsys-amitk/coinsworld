        <script src="<?php echo e(asset('assets/admin/global/plugins/jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/js.cookie.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/jquery.blockui.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js')); ?>" type="text/javascript"></script>

        <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/morris/morris.min.js')); ?>" type="text/javascript"></script>
          <script src="<?php echo e(asset('assets/admin/global/plugins/counterup/jquery.waypoints.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/counterup/jquery.counterup.min.js')); ?>" type="text/javascript"></script>


        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo e(asset('assets/admin/global/scripts/app.min.js')); ?>" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo e(asset('assets/admin/pages/scripts/dashboard.min.js')); ?>" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo e(asset('assets/admin/layouts/layout/scripts/layout.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/layouts/layout/scripts/demo.min.js')); ?>" type="text/javascript"></script>

        <!-- NicEditor -->
        <script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
        <script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
        <!-- Confirm -->
        <script src="<?php echo e(asset('assets/js/bootstrap-confirmation.js')); ?>"></script>
        
        <!-- DateTIme Picker -->
         <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap-daterangepicker/moment.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap-daterangepicker/daterangepicker.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js')); ?>" type="text/javascript"></script>
         <script src="<?php echo e(asset('assets/admin/pages/scripts/components-date-time-pickers.min.js')); ?>" type="text/javascript"></script>
         

<?php echo $__env->make('admin.layouts.data-table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       