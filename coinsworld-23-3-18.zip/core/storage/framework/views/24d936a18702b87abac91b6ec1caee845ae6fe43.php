    <div class="col-md-3">
        <!--Start Admin Menu-->
        <div class="admin-two-menu">
            <nav>
                <ul>
                    <li class="<?php echo e(request()->path() == 'home' ? 'admenuactive':''); ?>"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i>  Dashboard</a></li>
                    <li class="<?php echo e(request()->path() == 'home/withdraw' ? 'admenuactive':''); ?>"><a href="<?php echo e(route('withdraw')); ?>"><i class="fa fa-money"></i> Withdraw</a></li>
                    <li class="<?php echo e(request()->path() == 'home/deposit' ? 'admenuactive':''); ?>"><a href="<?php echo e(route('deposit')); ?>"><i class="fa fa-plus-square-o"></i>  Deposit</a></li>
                    <li data-toggle="modal" data-target="#sendmoney"><a href="#"><i class="fa fa-paper-plane-o"></i> Send Money</a></li>
                    <li class="<?php echo e(request()->path() == 'home/refered' ? 'admenuactive':''); ?>"><a href="<?php echo e(route('refered.users')); ?>"><i class="fa fa-file-text"></i> Reference Log</a></li>
                    <li> <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                <i class="fa fa-power-off"></i> Logout</a>
                                 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                     </li>

                               
                </ul>
            </nav>
        </div>
        <!--End Admin Menu-->
    </div>


  <!-- Send Money -->
<div id="sendmoney" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Send Money</h4>
      </div>
      <div class="modal-body">
        <form role="form" method="GET" action="<?php echo e(route('user.select')); ?>">
          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="sender" value="<?php echo e(Auth::user()->id); ?>">
          <div class="form-group">
           <label>Enter Username</label>
           <div class="input-group">
            <input type="text" name="reciver" class="form-control">
            <span class="input-group-addon"><i class="fa fa-user"></i></span>
          </div>
        </div>
        <div class="form-group">
          <label>Enter Amount</label>
          <div class="input-group">
            <input type="text" class="form-control" id="amount" name="amount">
            <span class="input-group-addon"><?php echo e($gset->curSymbol); ?></span>
          </div>
        </div>
        <div class="form-group">
         <button type="submit" class="btn btn-lg btn-success">Next</button>
       </div>

     </form>
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
  </div>
</div>

</div>
</div>
