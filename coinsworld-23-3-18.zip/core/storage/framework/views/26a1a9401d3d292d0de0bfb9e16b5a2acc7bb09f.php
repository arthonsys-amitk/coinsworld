<?php $__env->startSection('content'); ?>
<section class="section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <div class="main-login main-center">
                <div class="row text-center">
                  <h2>User Login</h2>
                </div>
                <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-md-12">
                        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
          <label for="username" class="cols-sm-2 control-label">Username</label>
          <div class="cols-sm-10">
            <div class="input-group">
              <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
              <input type="text" class="form-control input-sz" name="username" id="username"  placeholder="Enter Username" required />

        </div>
        <?php if($errors->has('username')): ?>
        <span class="help-block">
          <strong><?php echo e($errors->first('username')); ?></strong>
      </span>
      <?php endif; ?>
    </div>
</div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
      <label for="password" class="cols-sm-2 control-label">Password</label>
      <div class="cols-sm-10">
        <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-lock fa" aria-hidden="true"></i></span>
          <input type="password" class="form-control input-sz" name="password" id="password" required />
          <?php if($errors->has('password')): ?>
          <span class="help-block">
            <strong><?php echo e($errors->first('password')); ?></strong>
        </span>
        <?php endif; ?>
    </div>
</div>
</div>
                    <div class="form-group">

                            <div class="form-group ">
                              <button type="submit" class="submit-btn btn btn-lg btn-block login-button">Log In</button>
                          </div>

                          <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                            Forgot Your Password?
                        </a>
                </div>
                        </div>

                    </div>


            </form>
        </div>
    </div>


</div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>