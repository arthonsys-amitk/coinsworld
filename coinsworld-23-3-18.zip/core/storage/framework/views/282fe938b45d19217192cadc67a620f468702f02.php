 <nav class="main-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="Logo Image Will Be Here" width="15%"></a>
                    </div>
                </div>
                <div class="col-md-8 text-right">
                    <ul id="menu-bar">
                        <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('page', $menu->id)); ?>"><?php echo e($menu->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <!-- Authentication Links -->
                                <?php if(auth()->guard()->guest()): ?>
                                 <li><a href="#">Account <i class="fa fa-caret-down"></i></a>

                                    <ul class="sub-menu">
                                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                    <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                                <?php else: ?>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                           <?php echo e(Auth::user()->firstname); ?>

                                            <span class="caret"></span>
                                        </a>

                                        <ul class="dropdown-menu" role="menu">
                                            <li>
                                                <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('logout')); ?>"
                                                    onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                                                    Logout
                                                </a>

                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                    <?php echo e(csrf_field()); ?>

                                                </form>
                                            </li>
                                            
                                        </ul>
                                    </li>
                                 <?php endif; ?>
                            </ul>
                </div>
            </div>
        </div>
    </nav>