<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($content['title']); ?>


<?php echo e($content['body']); ?>


<?php $__env->startComponent('mail::table'); ?>
| Laravel       | Table         | Example  |
| ------------- |:-------------:| --------:|
| PHP           | Centered      | $100     |
| Laravel       | Right-Aligned | $200     |
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
<?php echo e($content['button']); ?>

<?php echo $__env->renderComponent(); ?>

Thanks,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>