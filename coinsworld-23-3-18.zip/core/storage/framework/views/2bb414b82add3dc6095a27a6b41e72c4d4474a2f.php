<?php $__env->startSection('content'); ?>
<section class="admin-two dashboard">
  <!--Start Container-->
  <div class="container">
    <!--Start Admin Wrap-->
    <div class="admin-two-wrap">
      <!--Start Admin Wrap Row-->
      <div class="row">
        <!--Start Admin Menu Col-->
        <?php echo $__env->make('front.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--Start Admin Content Col-->
        <div class="col-md-8 col-md-offset-2">
          <!--Start Admin Content-->
          <div class="admin-two-cont">
            <!--Start Dashboard-->
            <div class="admin-dashboard">
              <div class="row">
                <!--Start Visitors Country-->

                <div class="col-md-12">
                  <div class="main-login main-center">
                    <h2>Change Password</h2>
                    <hr style="width:100%;">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('changep')); ?>">
                      <?php echo e(csrf_field()); ?>

                      <div class="row">
                        <div class="col-md-12">
                          <div class="form-group<?php echo e($errors->has('passwordold') ? ' has-error' : ''); ?>">
                            <label for="password" class="cols-sm-2 control-label">Old Password</label>
                            <div class="cols-sm-10">
                              <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock fa" aria-hidden="true"></i></span>
                                <input type="password" class="form-control input-sz" name="passwordold" id="passwordold" required />
                                <?php if($errors->has('passwordold')): ?>
                                <span class="help-block">
                                  <strong><?php echo e($errors->first('passwordold')); ?></strong>
                                </span>
                                <?php endif; ?>
                              </div>
                            </div>
                          </div>

                          <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="cols-sm-2 control-label">New Password</label>
                            <div class="cols-sm-10">
                              <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-lock fa" aria-hidden="true"></i></span>
                                <input type="password" class="form-control input-sz" name="password" id="password" required />
                                <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                  <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                                <?php endif; ?>
                              </div>
                            </div>
                          </div>
                          <div class="form-group">
                             <label for="password-confirm" class="cols-sm-2 control-label">Confirm Password</label>

                             <div class="cols-sm-10">
                                 <div class="input-group">
                                   <span class="input-group-addon"><i class="fa fa-lock fa" aria-hidden="true"></i></span>
                                   <input id="password-confirm" type="password" class="form-control input-sz" name="password_confirmation" required>
                                   <?php if($errors->has('password')): ?>
                                   <span class="help-block">
                                     <strong><?php echo e($errors->first('password')); ?></strong>
                                 </span>
                                 <?php endif; ?>
                             </div>
                         </div>
                         </div>
                            <div class="form-group ">
                              <button type="submit" class="submit-btn btn btn-lg btn-block login-button">Change Password</button>
                            </div>
                        </div>

                      </div>
                    </form>
                  </div>
                </div>

                <!--End Dashboard-->
              </div>
              <!--End Admin Content-->
            </div>
            <!--End Admin Content Col-->
          </div>
          <!--End Admin Wrap-->
        </div>
      </div>
    </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>