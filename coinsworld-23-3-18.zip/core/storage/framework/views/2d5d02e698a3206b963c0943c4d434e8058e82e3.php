<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-list font-blue"></i>
                        <span class="caption-subject font-green bold uppercase">Edit <?php echo e($page-> name); ?> Menu</span>
                    </div>
                    <div class="actions">
                        <a class="btn btn-circle  btn-default" href="<?php echo e(route('menu.index')); ?>">
                            <i class="fa fa-backward"></i> Back
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <form role="form" method="POST" action="<?php echo e(route('menu.update', $page->id)); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('put')); ?>

                        <div class="form-body">
                            <div class="form-group">
                                <label>Menu Name</label>
                                <input type="text" class="form-control input-lg" name="name" value="<?php echo e($page-> name); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Menu Order</label>
                            <select class="form-control" name="order">
                                <?php for($i = 1; $i < 50; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e($page->order == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Page Content</label>
                            <textarea name="content" class="form-control" rows="10">
                                <?php echo e($page-> content); ?>

                            </textarea>
                        </div>
                        <div class="form-actions right">
                            <button type="submit" class="btn blue btn-lg">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>