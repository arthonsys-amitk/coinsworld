<?php $__env->startSection('content'); ?>
<section class="admin-two dashboard">
<!--Start Container-->
<div class="container">
<!--Start Admin Wrap-->
<div class="admin-two-wrap">
<!--Start Admin Wrap Row-->
<div class="row">
<!--Start Admin Menu Col-->
<?php echo $__env->make('front.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Start Admin Content Col-->
<div class="col-md-9">
<!--Start Admin Content-->
<div class="admin-two-cont">
<!--Start Dashboard-->
<div class="admin-dashboard">       	
		<div class="row">
<!--Start Visitors Country-->
<div class="admin-vistitor-country">
<div class="col-md-12">
 

<form action="https://secure.paypal.com/cgi-bin/webscr" method="post" id="myform">
<input type="hidden" name="cmd" value="_xclick" />
<input type="hidden" name="business" value="<?php echo e($paypal['sendto']); ?>" />
<input type="hidden" name="cbt" value="<?php echo e($gset->webTitle); ?>" />
<input type="hidden" name="currency_code" value="USD" />
<input type="hidden" name="quantity" value="1" />
<input type="hidden" name="item_name" value="Add Money To <?php echo e($gset->webTitle); ?> Account" />
<input type="hidden" name="custom" value="<?php echo e($paypal['track']); ?>" />
<input type="hidden" name="amount"  value="<?php echo e($paypal['amount']); ?>" />
<input type="hidden" name="return" value="<?php echo e(route('home')); ?>"/>
<input type="hidden" name="cancel_return" value="<?php echo e(route('home')); ?>" />
<input type="hidden" name="notify_url" value="<?php echo e(route('ipn.paypal')); ?>" />
</div>
</form>




</div>	
<!--End Dashboard-->
</div>
<!--End Admin Content-->
</div>
<!--End Admin Content Col-->
</div>
<!--End Admin Wrap-->
</div>
</div>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
document.getElementById("myform").submit();
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>