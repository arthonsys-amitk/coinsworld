<?php $__env->startSection('content'); ?>
<section class="admin-two dashboard">
<!--Start Container-->
<div class="container">
<!--Start Admin Wrap-->
<div class="admin-two-wrap">
<!--Start Admin Wrap Row-->
<div class="row">
<!--Start Admin Menu Col-->
<?php echo $__env->make('front.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Start Admin Content Col-->
<div class="col-md-9">
<!--Start Admin Content-->
<div class="admin-two-cont">
<!--Start Dashboard-->
<div class="admin-dashboard">

        <div class="row">
          <div class="panel panel-success">
            <div class="panel-heading">
              <h1>Refered User Log</h1>
            </div>
            <div class="panel-body">
                <div class="col-md-12">
                  <div class="panel panel-warning">
                    <div class="panel-heading">Refered Users of Today</div>
                    <div class="panel-body">
                      <table class="table table-responsive table-stripped">
                              <tr>
                                <th>
                                  Username
                                </th>
                                <th>
                                  Commission
                                </th>
                              </tr>
                                <?php $__currentLoopData = $today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td>
                                      <?php echo e($tod->user); ?> 
                                  </td>                       
                                  <td>
                                    <?php echo e($tod->commis); ?> <?php echo e($gset->curSymbol); ?>

                                  </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                <tr>
                              </tr> 
                        </table>    
                    </div>
                  </div>
                </div>
     <div class="col-md-12">
          <div class="panel panel-primary">
            <div class="panel-heading">Refered Users</div>
            <div class="panel-body">
              <table class="table table-responsive table-stripped">
                      <tr>
                        <th>
                           Name
                        </th>
                         <th>
                          Date of Join
                        </th>
                        <th>
                          Package
                        </th>
                      </tr>
                        <?php $__currentLoopData = $refers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td>
                              <?php echo e($ref-> firstname); ?> <?php echo e($ref-> lastname); ?>

                          </td>                       
                           <td>
                            <?php echo e($ref-> created_at); ?>

                          </td>
                           <td>
                            <?php echo e($ref-> package_id == 2 ? 'Premium' : 'Free'); ?>

                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                      </table>    
            </div>
          </div>
        </div>

      </div>
<!--End Dashboard-->
</div>
<!--End Admin Content-->
</div>
<!--End Admin Content Col-->
</div>
<!--End Admin Wrap-->
</div>
</div>
</section>
<?php $__env->stopSection(); ?>


      
<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>