 <nav class="main-menu nav-fixed">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>"
                          alt="Logo Image Will Be Here" style="max-width:280px; max-height: 30px;" ></a>
                    </div>
                </div>
<div class="col-md-8 text-right">
    <ul id="menu-bar">
   

 
<li class="mobile-menu"><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard" aria-hidden="true"></i> Dashboard</a></li>
<li class="muteside mobile-menu">Transactions ---</li>
<li class="mobile-menu"><a href="<?php echo e(route('coinlog')); ?>"><img src="<?php echo e(asset('assets/images/coin/nc.png')); ?>" class="side-icon img-responsive" style="filter:invert(1) opacity(1);"> <?php echo e($gset->curCode); ?></a>
</li>
<li class="mobile-menu"><a href="<?php echo e(route('bitlog')); ?>">
<img src="<?php echo e(asset('assets/images/coin/btc.png')); ?>" class="side-icon img-responsive" style="filter:invert(1) opacity(1);"> BitCoin</a>
</li>
<li class="muteside mobile-menu">--------------------------</li>

<li class="mobile-menu"><a href="<?php echo e(route('deposit')); ?>"><i class="fa fa-credit-card" aria-hidden="true"></i> Buy <?php echo e($gset->curCode); ?></a></li>
<li class="mobile-menu"><a href="<?php echo e(route('sell.coin')); ?>"><i class="fa fa-money" aria-hidden="true"></i> Sell <?php echo e($gset->curCode); ?></a></li>
<li class="mobile-menu"><a href="<?php echo e(route('convert')); ?>""><i class="fa fa-arrows" aria-hidden="true"></i> Convert</a></li>
<li class="mobile-menu"><a href="<?php echo e(route('deposit')); ?>"><i class="fa fa-credit-card" aria-hidden="true"></i> Deposit</a></li>
<li class="mobile-menu"><a href="<?php echo e(route('transactions')); ?>"><i class="fa fa-money" aria-hidden="true"></i> Transaction Log</a></li>        
<?php if(Auth::user()->docv != '1'): ?>
<li class="mobile-menu"><a href="<?php echo e(route('document')); ?>"> Verify Document</a></li>
<?php endif; ?>
<li>
    <a href="<?php echo e(route('logout')); ?>"
    onclick="event.preventDefault();
    document.getElementById('logout-form').submit();">
    SIGN OUT
</a>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

</form>
</li>

                    </ul>
                </div>
            </div>
        </div>
    </nav>



