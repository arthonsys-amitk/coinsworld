<?php $__env->startSection('content'); ?>
<section class="admin-two dashboard">
<!--Start Container-->
<div class="container">
<!--Start Admin Wrap-->
<div class="admin-two-wrap">
<!--Start Admin Wrap Row-->
<div class="row">
<!--Start Admin Menu Col-->
<?php echo $__env->make('front.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Start Admin Content Col-->
<div class="col-md-9">
<!--Start Admin Content-->
<div class="admin-two-cont">
<!--Start Dashboard-->
<div class="admin-dashboard">             
      <div class="row">
            <div class="panel panel-success">
<div class="panel-heading">
<h1>Deposit Methods</h1>
</div>
<div class="panel-body">
<?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4">
      <div class="panel panel-default">
            <div class="panel-heading" style="padding: 20px; font-size: 20px;"><?php echo e($method->name); ?></div>
            <div class="panel-body">
                  <div class="well">
                        <img src="<?php echo e(asset('assets/images/gateway')); ?>/<?php echo e($method->gateimg); ?>" class="img-responsive" width="100%"> 
                  </div>
                  
                  <div class="well">
                        <table class="table table-responsive table-bordered">
                              <tr>
                                    <td>Deposit Limit:</td>
                                    <td><b><?php echo e($method->minamo); ?></b> <?php echo e($gset->curSymbol); ?> ~ <b><?php echo e($method->maxamo); ?></b>    <?php echo e($gset->curSymbol); ?></td>
                              </tr>
                              <tr>
                                    <td>Charge</td>
                                    <td><b><?php echo e($method->charged); ?></b> <?php echo e($gset->curSymbol); ?> + <b><?php echo e($method->chargep); ?></b>  %
                                    </td>
                              </tr>
                              <tr>
                                    <td>Conversion Rate</td>
                                    <td><b>1</b> <?php echo e($method->currency); ?> = <b><?php echo e($method->rate); ?></b> <?php echo e($gset->curSymbol); ?></td>
                              </tr>
                        </table>
                  </div>
                  
            </div>
            <div class="panel-footer"><div class="form-group ">
                  <button type="button" class="submit-btn btn btn-lg btn-block login-button" data-toggle="modal" data-target="#wd<?php echo e($method->id); ?>">Deposit Now</button>
            </div></div>
      </div>
</div>

<!-- Deposit -->
<div class="modal fade" id="wd<?php echo e($method->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
            <div class="modal-content">
                  <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e($method->name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                        </button>
                  </div>
                  <div class="modal-body">
                        <form role="form" method="GET" action="<?php echo e(route('deposit.confirm')); ?>" >
                              <?php echo e(csrf_field()); ?>

                              <input type="hidden" name="method" value="<?php echo e($method->id); ?>">
                              <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                              <div class="form-group">
                                    <label for="amount">Amount</label>
                                     <div class="input-group">
                                          <input type="text" class="form-control" id="amount" name="amount">
                                           <span class="input-group-addon"><?php echo e($gset->curSymbol); ?></span>
                                    </div>
                              </div>
                              <button type="submit" class="btn btn-primary">Next</button>
                        </form>
                  </div>
                  <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>

            </div>
      </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
</div>
</div>
<!--End Dashboard-->
</div>
<!--End Admin Content-->
</div>
<!--End Admin Content Col-->
</div>
<!--End Admin Wrap-->
</div>
</div>
</section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>