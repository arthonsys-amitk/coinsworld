<?php $__env->startSection('content'); ?>
<section class="section-padding about-us-page">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
      <div class="main-login main-center">
        <a href="<?php echo e(route('index')); ?>"><h2 class="reg-head"><?php echo e(App\Gsetting::find(1)->webTitle); ?></h2></a>
        <hr/>
          <form class="form-horizontal" method="post" action="#">
            <div class="row">
            	<div class="col-md-6 ">
            		 <div class="form-group">
		              <label for="name" class="cols-sm-2 control-label">Refference ID</label>
		              <div class="cols-sm-10">
		                <div class="input-group">
		                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
		                  <input type="text" class="form-control input-sz" name="name" id="name"  placeholder="Enter your Refference ID"/>
		                </div>
		              </div>
		            </div>
            	</div>
            	<div class="col-md-6 ">
            		<div class="form-group">
		              <label for="name" class="cols-sm-2 control-label">Position</label>
		              <div class="cols-sm-10">
		                <div class="input-group">
		                  <span class="input-group-addon"><i class="fa fa-users fa" aria-hidden="true"></i></span>
		                  <select class="form-control input-sz">
		                  	<option>Position</option>
		                  	<option value="right">Right</option>
		                  	<option value="left">Left</option>
		                  </select>
		                </div>
		              </div>
		            </div>
            	</div>
            </div>

           <div class="row">
           		<div class="col-md-6">
           			<div class="form-group">
		              <label for="name" class="cols-sm-2 control-label">First Name</label>
		              <div class="cols-sm-10">
		                <div class="input-group">
		                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
		                  <input type="text" class="form-control input-sz" name="name" id="name"  placeholder="Enter your First Name"/>
		                </div>
		              </div>
           			 </div>
           		</div>
           		<div class="col-md-6">
           			<div class="form-group">
		              		<label for="name" class="cols-sm-2 control-label">Last Name</label>
		              		<div class="cols-sm-10">
			                <div class="input-group">
			                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
			                  <input type="text" class="form-control input-sz" name="name" id="name"  placeholder="Enter Last your Name"/>
			                </div>
	             		 </div>
           		   </div>
           		</div>
           </div>

           <div class="row">
           		<div class="col-md-6">
           			<div class="form-group"> <!-- Date input -->
				        <label for="number" class="cols-sm-2 control-label">Date</label>
		              <div class="cols-sm-10">
		                <div class="input-group">
		                  <span class="input-group-addon"><i class="fa fa-calendar fa" aria-hidden="true"></i></span>
				        <input class="form-control input-sz" id="date" name="date" placeholder="MM/DD/YYY" type="text"/>
				    </div></div>
			      	</div>
           		</div>
           		<div class="col-md-6">
           			
		            <div class="form-group">
		              <label for="number" class="cols-sm-2 control-label">Phone</label>
		              <div class="cols-sm-10">
		                <div class="input-group">
		                  <span class="input-group-addon"><i class="fa fa-phone fa" aria-hidden="true"></i></span>
		                  <input type="text" class="form-control input-sz" name="number" id="number"  placeholder="Enter your Phone Number"/>
		                </div>
		              </div>
		            </div>
           		</div>
           </div>

           <div class="row">
           	<div class="col-md-6">
           		 <div class="form-group">
		              <label for="number" class="cols-sm-2 control-label">Email</label>
		              <div class="cols-sm-10">
		                <div class="input-group">
		                  <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
		                  <input type="text" class="form-control input-sz" name="email" id="email"  placeholder="Enter your Email"/>
		                </div>
		              </div>
		            </div>
           	</div>
           	<div class="col-md-6">
           		<div class="form-group">
	              <label for="street" class="cols-sm-2 control-label">Street</label>
	              <div class="cols-sm-10">
	                <div class="input-group">
	                  <span class="input-group-addon"><i class="fa fa-road fa" aria-hidden="true"></i></span>
	                  <input type="text" class="form-control input-sz" name="street" id="street"  placeholder="Enter your Steet Address"/>
	                </div>
	              </div>
	            </div>
           	</div>
           </div>

           <div class="row">
           	<div class="col-md-4">
           		 <div class="form-group">
		              <label for="city" class="cols-sm-2 control-label">City/State</label>
		              <div class="cols-sm-10">
		                <div class="input-group">
		                  <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
		                  <input type="text" class="form-control input-sz" name="city" id="city"  placeholder="Enter your City Name"/>
		                </div>
		              </div>
		            </div>
           	</div>
           		<div class="col-md-4">
           		<div class="form-group">
	              <label for="street" class="cols-sm-2 control-label">Post Code</label>
	              <div class="cols-sm-10">
	                <div class="input-group">
	                  <span class="input-group-addon"><i class="fa fa-road fa" aria-hidden="true"></i></span>
	                  <input type="text" class="form-control input-sz" name="street" id="street"  placeholder="Enter your Steet Address"/>
	                </div>
	              </div>
	            </div>
           	</div>
           	<div class="col-md-4">
           		<div class="form-group">
	              <label for="street" class="cols-sm-2 control-label">Country</label>
	              <div class="cols-sm-10">
	                <div class="input-group">
	                  <span class="input-group-addon"><i class="fa fa-road fa" aria-hidden="true"></i></span>
	                  <input type="text" class="form-control input-sz" name="street" id="street"  placeholder="Enter your Steet Address"/>
	                </div>
	              </div>
	            </div>
           	</div>
           
           </div>
            
            <div class="form-group">
              <label for="username" class="cols-sm-2 control-label">Username</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="username" id="username"  placeholder="Enter your Username"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="password" class="cols-sm-2 control-label">Password</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                  <input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"/>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="confirm" class="cols-sm-2 control-label">Confirm Password</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                  <input type="password" class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
                </div>
              </div>
            </div>
              <div class="form-group">
		            <label class="checkbox margin-bottom-20">
				<input type="checkbox" name="terms">
				<i></i>
				I have read agreed with the <a href="#">terms &amp; conditions</a>
				</label>
			</div>
            <div class="form-group ">
              <button type="button" class="submit-btn btn btn-lg btn-block login-button">Register</button>
            </div>
          </form>
        </div>   
       </div>
                

             </div>
        </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>