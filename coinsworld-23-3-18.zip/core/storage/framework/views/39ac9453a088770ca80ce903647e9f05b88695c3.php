        <div id="header" class="header navbar navbar-default navbar-fixed-top">
            <!-- begin container-fluid -->
            <div class="container-fluid">
                <!-- begin mobile sidebar expand / collapse button -->
                <div class="navbar-header">
                    <a href="<?php echo e(url('admin/home')); ?>" class="navbar-brand">
                        <img class="img-responsive" src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" style="max-width: 60%; ">
                    </a>
                    <button type="button" class="navbar-toggle" data-click="sidebar-toggled">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>

                <ul class="nav navbar-nav navbar-right">

                    <li>
                        <span class="btn btn-primary btn-md">1 BTC = $<?php echo e(rtrim(number_format(floatval($btcrate) , $gset->decimalPoint, '.', ''),'.0')); ?></span>
                    </li>
                    <li>
                        <span class="btn btn-primary btn-md" style="margin-left:5px; margin-right: 20px;">1 <?php echo e($gset->curCode); ?> = $<?php echo e(rtrim(number_format(floatval($crate) , $gset->decimalPoint, '.', ''),'.0')); ?></span>
                    </li>
                </ul>
                

            </div>
            <!-- end container-fluid -->
        </div>
        <!-- end #header -->



