<?php $__env->startSection('content'); ?>
   <section class="breadcrumb-section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <!-- breadcrumb Section Start -->
            <div class="breadcrumb-content">
              <h5>Search Result</h5>
            </div>
            <!-- Breadcrumb section End -->
          </div>
        </div>
      </div>
    </section>
  <div class="clearfix"></div>
  <div class="clearfix"></div>

          <div class="panel panel-info">
            <div class="panel-body">
          <div class="panel panel-primary">
            <div class="panel-body">
              <table class="table table-responsive">
              <thead>
                  <tr>
                    
              <th>
                Transaction ID
              </th>
               <th>
                Wallet ID
              </th>
              <th>
                Amount
              </th>
            </tr>
              </thead>
              <tbody>
   <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td>
<?php echo e($log->trxid); ?>

</td>
<td>
  <?php echo e($log->toacc); ?>

</td>
<td>
 <button class="btn <?php echo e($log->status == '1' ? 'btn-success' : 'btn-danger'); ?>">
   <?php echo e(rtrim(number_format(floatval($log->amount), $gset->decimalPoint, '.', ''),'.0')); ?>

 </button>   
</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
              </tbody>
          </table>
             
            </div>
          </div>

      </div>

</div>


<?php $__env->stopSection(); ?>


      
<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>