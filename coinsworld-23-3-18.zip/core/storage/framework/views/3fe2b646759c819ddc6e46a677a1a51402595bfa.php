<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo e($gset->webTitle); ?></title>
        <!--Favicon add-->
        <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/logo/icon.png')); ?>">
    
        <!--bootstrap Css-->
        <link href="<?php echo e(asset('assets/front/css/bootstrap.min.css ')); ?>" rel="stylesheet">
        <!--font-awesome Css-->
        <link href="<?php echo e(asset('assets/front/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <!--owl.carousel Css-->
        <link href="<?php echo e(asset('assets/front/css/owl.carousel.css')); ?>" rel="stylesheet">
        <!--Slick Nav Css-->
        <link href="<?php echo e(asset('assets/front/css/slicknav.min.css')); ?>" rel="stylesheet">
        <!-- rangeslider Css-->
        <link href="<?php echo e(asset('assets/front/css/asRange.css')); ?>" rel="stylesheet">
        <!--Style Css-->
        <link href="<?php echo e(asset('assets/front/css/style.css')); ?>" rel="stylesheet">
        <!--Responsive Css-->
        <link href="<?php echo e(asset('assets/front/css/responsive.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/front/css/color.php?color=')); ?><?php echo e(App\Gsetting::find(1)->colorCode); ?>" rel="stylesheet">
        
        <link href="<?php echo e(asset('assets/front/css/register.css')); ?>" rel="stylesheet">

        <link href="<?php echo e(asset('assets/admin/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')); ?>" rel="stylesheet" type="text/css" />

        <script src="<?php echo e(asset('assets/front/js/jquery.js')); ?>"></script>

         <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
           <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>

            <!-- Admin -->

    <!--Bootstrap Select Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/front/admin/css/bootstrap-select.css')); ?>">
    <!--Input Select With Search Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/front/admin/css/select2.css')); ?>">
    <!--Font Awesome Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/front/admin/css/font-awesome.min.css')); ?>">
    <!--Animate Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/front/admin/css/animate.css')); ?>">
    <!--Main Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/front/admin/css/style.css')); ?>">
    <!--Responsive Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/front/admin/css/responsive.css')); ?>">
    <!--Custom Color Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/front/admin/css/switcher-colors.css')); ?>">

        <!-- Modanizr JS -->
    <script src="<?php echo e(asset('assets/front/admin/js/modernizr.custom.js')); ?>"></script>
           
        
    </head>