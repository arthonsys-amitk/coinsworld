<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-list font-green"></i>
                        <span class="caption-subject font-green bold uppercase">Add New Menu</span>
                    </div>
                    <div class="actions">
                        <a class="btn btn-circle  btn-default" href="<?php echo e(route('menu.index')); ?>">
                            <i class="fa fa-list"></i> All Menu List
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <form role="form" method="POST" action="<?php echo e(route('menu.store')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-body">
                            <div class="form-group">
                                <label>Menu Name</label>
                                <input type="text" class="form-control input-lg" name="name" placeholder="Menu Name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Menu Order</label>
                            <select class="form-control" name="order">
                                <?php for($i = 1; $i < 50; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Page Content</label>
                            <textarea name="content" class="form-control" name="content" rows="10">

                            </textarea>


                        </div>
                        <div class="form-actions right">
                            <button type="submit" class="btn blue btn-lg">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>